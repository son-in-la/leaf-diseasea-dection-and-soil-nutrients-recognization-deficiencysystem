from keras.models import load_model
from PIL import Image, ImageOps
import numpy as np
import serial
import time
model = load_model('vgg-rps-final.h5')
import cv2
cap = cv2.VideoCapture(0)

print("running")
def predict():
       data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
       image = Image.open('captured_image.jpg')
       size = (224, 224)
       image = ImageOps.fit(image, size, Image.ANTIALIAS)

       image_array = np.asarray(image)
       normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
       data[0] = normalized_image_array

       prediction = model.predict(data)

       y_classes = prediction.argmax(axis=-1)
       accu=prediction[0][y_classes]*100
       pred=""
       with serial.Serial("COM6", 9600, timeout=1) as arduino:
            if arduino.isOpen():
                   print("{} connected!".format(arduino.port))
                   time.sleep(5)
                   if y_classes==0:
                       pred = "healthy"
                       print("Healthy with accuracy: ",accu)
                   elif y_classes==1:
                       pred = "Unhealthy"
                       print("Unhealthy with accuracy: ",accu)
                   #else:
                       # pred = "Undiseased"
                   print(pred)
                   arduino.write(pred.encode())

while True:
       ret, frame = cap.read()
       cv2.imshow('Camera', frame)

       if cv2.waitKey(1) == ord('s'):
              cv2.imwrite('captured_image.jpg', frame)
              print("Image captured successfully!")
              predict()

       if cv2.waitKey(1) == ord('q'):
              break

cap.release()
cv2.destroyAllWindows()
